package com.example.assignment_02_newspaper_delivery;

import androidx.fragment.app.FragmentActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.assignment_02_newspaper_delivery.databinding.ActivityDeliveryMapBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DeliveryMapActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityDeliveryMapBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDeliveryMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        new ReadJSONFeedTask().execute("http://"+MainActivity.localhost+"/Android/DeliveryPlan.json");

        mMap.addMarker(new MarkerOptions().position(new LatLng(6.894224, 79.913192)).title("No:283/B"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(6.894906, 79.898773)).title("No:20"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(6.903768, 79.920402)).title("No:10,Saman Rd"));
    }
    public String readJSONFeed(String address){
        URL url = null;

        try{
            url = new URL(address);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        };
        StringBuilder stringBuilder = new StringBuilder();
        HttpURLConnection urlConnection = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            InputStream content = new BufferedInputStream(urlConnection.getInputStream());
            BufferedReader reader = new BufferedReader(new InputStreamReader(content));
            String line;
            while ((line = reader.readLine()) != null){
                stringBuilder.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            urlConnection.disconnect();
        }

        return stringBuilder.toString();
    }

    private class ReadJSONFeedTask extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            return readJSONFeed(urls[0]);
        }

        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObject = new JSONObject(result);
                JSONArray customersArray = jsonObject.getJSONArray("customers");
                JSONArray subscriptionArray = jsonObject.getJSONArray("Subscription");

                List<LatLng> dropOffLocations = new ArrayList<>();

                for (int i = 0; i < customersArray.length(); i++) {
                    JSONObject customerObject = customersArray.getJSONObject(i);
                    String address = customerObject.getString("Address");
                    String street = customerObject.getString("Street");
                    String latitude = customerObject.getString("latitude");
                    String longitude = customerObject.getString("longitude");

                    // Use the downloaded details as required
                    Log.i("JSON", "Address: " + address);
                    Log.i("JSON", "Street: " + street);
                    Log.i("JSON", "Latitude: " + latitude);
                    Log.i("JSON", "Longitude: " + longitude);

                    // Get the subscription details for the customer
                    JSONObject subscriptionObject = subscriptionArray.getJSONObject(i);
                    String subscriptionStatus = subscriptionObject.optString("ReminderStatus", "");
                    String newspaperID = subscriptionObject.getString("NewspaperID");
                    String startDate = subscriptionObject.getString("StratDate");
                    String endDate = subscriptionObject.getString("EndDate");

                    // Use the subscription details as required
                    Log.i("JSON", "Subscription Status: " + subscriptionStatus);
                    Log.i("JSON", "Newspaper ID: " + newspaperID);
                    Log.i("JSON", "Start Date: " + startDate);
                    Log.i("JSON", "End Date: " + endDate);

                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                    Date parsedEndDate = null;
                    try {
                        parsedEndDate = dateFormat.parse(endDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    if (parsedEndDate != null) {
                        // Compare the end date with the current date
                        Date currentDate = new Date();
                        boolean endDateReached = parsedEndDate.compareTo(currentDate) <= 0;

                        // Usage in the if condition
                        boolean issueReminder = !subscriptionStatus.isEmpty() && endDateReached;

                        // Print the end date
                        Log.i("JSON", "End Date: " + parsedEndDate);

                        String deliveryStatus = "Delivered";
                        String timestamp = "2023-06-08 10:00:00";

                        boolean unableToDeliver = true;
                        String note = "Premises closed";
                        if (unableToDeliver) {
                            Log.i("Delivery", "Unable to deliver. Note: " + note);
                        }

                        // Issue renewal reminder
                        if (issueReminder) {
                            Log.i("Delivery", "Renewal reminder issued: " + subscriptionStatus);
                        }

                        // Add drop-off location to the list
                        double lati = Double.parseDouble(latitude);
                        double logi = Double.parseDouble(longitude);
                        dropOffLocations.add(new LatLng(lati, logi));
                    }
                }

                // Move the camera to the first drop-off location
                if (!dropOffLocations.isEmpty()) {
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(dropOffLocations.get(0), 12.0f));
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}


