package com.example.assignment_02_newspaper_delivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Registration extends AppCompatActivity {

    EditText txtStaffID, txtName, txtID, txtPassword;
    Button btnSignUp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        txtStaffID = findViewById(R.id.txtStaffID);
        txtName = findViewById(R.id.txtName);
        txtID = findViewById(R.id.txtID);
        txtPassword = findViewById(R.id.txtPassword);
        btnSignUp = findViewById(R.id.btnSignUp);


        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String staffID = txtStaffID.getText().toString();
                String name = txtName.getText().toString();
                String id = txtID.getText().toString();
                String password = txtPassword.getText().toString();

                // Perform the database insertion using the retrieved values
                insertDataIntoDatabase(staffID, name, id, password);
            }
        });

        Intent mainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(mainActivityIntent);
        finish();
    }

    private void insertDataIntoDatabase(String staffID, String name, String id, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/newspaper_deliverydb", "root", " ");
            Statement statement = connection.createStatement();
            String query = "INSERT INTO distributor (StaffID, Name, UserID, Password) VALUES ('" + staffID + "', '" + name + "', '" + id + "', '" + password + "')";
            statement.executeUpdate(query);
            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

}