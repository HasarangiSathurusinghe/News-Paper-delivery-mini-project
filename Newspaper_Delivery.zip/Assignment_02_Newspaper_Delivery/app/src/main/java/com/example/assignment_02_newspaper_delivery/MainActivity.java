package com.example.assignment_02_newspaper_delivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity {
    public static final String localhost = "172.15.0.98";
     EditText editTextID, editTextPassword;
    Button buttonLogin,buttonSignUp;
    TextView textViewError;

    private class  LoginTask extends AsyncTask<String,String,String>{

        @Override
        protected String doInBackground(String... args) {
            try{
                String userId = args[0];
                String pass= args[1];

                String link = "http://"+localhost+"/Android/UserLogin.php";
                String data = URLEncoder.encode("username", "UTF-8") + "=" + URLEncoder.encode(userId, "UTF-8");
                data+= "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(pass, "UTF-8");

                URL url = new URL(link);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);

                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
                writer.write(data);
                writer.flush();
                writer.close();
                outputStream.close();


                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

                StringBuilder sb = new StringBuilder();
                String line = null;

                // Read Server Response
                while((line = reader.readLine()) != null) {
                    sb.append(line);
                    break;
                }
                Log.d("Login", "doInBackground: "+sb.toString());
                return sb.toString();


            }catch (Exception e){
                Log.d("Login", "doInBackground: "+e.getMessage());
                return "error2";
            }

        }
        @Override
        protected void onPostExecute(String result){

            if(!result.equals("error2")){
                if(result.equals(result)){
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);

                    startActivity(intent);
                }else{
                    textViewError.setText("Invalid ID or password");
                }

            }else{
                textViewError.setText("Invalid ID or password");
            }
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editTextID = (EditText) findViewById(R.id.txtID);
        editTextPassword = (EditText)findViewById(R.id.txtPassword);
        buttonLogin = findViewById(R.id.btnLogin);
        buttonSignUp = findViewById(R.id.btnSignUp);
        textViewError = (TextView) findViewById(R.id.txtViewError);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform login authentication
                String id = editTextID.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                LoginTask login = new LoginTask();
                login.execute(id,password);

            }
        });

        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the registration activity
                Intent intent = new Intent(MainActivity.this, Registration.class);
                startActivity(intent);
            }
        });
    }


}
